# React-Native
Tela de login e cadastro de usuário com react native usando react navigation v5.


![Tela-login](https://user-images.githubusercontent.com/63432537/88991014-e6202000-d2b5-11ea-924a-3d91cad6d479.png)
![Tela-Cadastror](https://user-images.githubusercontent.com/63432537/88991023-e8827a00-d2b5-11ea-88b1-a7c843b4c886.png)

https://www.figma.com/proto/7iK9LN6UmrJQPpVcNXl09T/React-native-login?node-id=0%3A1
